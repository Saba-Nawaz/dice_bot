1- Write the path of resume

   Example: C:\Users\saban\PycharmProjects\Final_dicebot\resume.pdf

2- Those keywords are basically the hard filters / must-have skills your script is looking for
  
   in each job description before it decides if it’s a match. 
   
   Example for sarfraz profile: python, javascript, typescript, react, node.js, aws, docker, ci/cd, graphql

3- Enter Email:  sarfraz.dev25@gmail.com

4- Enter Password: Jani@2025!!

5- Enter titles for job search 

   Example for sarfraz profile:

   Full Stack Developer, Full Stack Engineer, Backend Developer, Senior Backend Engineer,  Frontend Developer, WordPress Developer, DevOps Engineer, eCommerce Developer, Lead Web,  Developer, Senior Software Engineer, Principal Software Engineer

   
   Note: fetched jobs will be saves in matched_jobs_hybrid.xlsx