from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException
import time
import PyPDF2
import openpyxl
import re
from sentence_transformers import SentenceTransformer, util
from fuzzywuzzy import fuzz
import os
import warnings
import tkinter as tk
from tkinter import filedialog
import getpass
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"  # hide INFO and WARNING from TF
warnings.filterwarnings("ignore", category=DeprecationWarning)        # hide all Python warnings

# ====== STEP 1: Extract text from resume ======
# select resume from device
# --- Ask user to pick PDF resume ---
root = tk.Tk()
root.withdraw()

# Set the initial folder (example: Desktop)
initial_folder = os.path.expanduser("~/Desktop")  # You can change this to any path

print("📂 Please select your resume (PDF only)...")
resume_path = filedialog.askopenfilename(
    title="Select Resume (PDF only)",
    filetypes=(("PDF Files", "*.pdf"),),
    initialdir=initial_folder
)

if not resume_path:
    print("No file selected. Exiting...")
    exit(1)

print(f"Resume selected: {resume_path}")

resume_text = ""

with open(resume_path, "rb") as file:
    reader = PyPDF2.PdfReader(file)
    for page in reader.pages:
        resume_text += page.extract_text() + " "

resume_text = resume_text.strip()
# input keywords of resume that describes complete skills of resume
# --- Take keywords as input ---

user_input = input("Enter keywords separated by commas: ")
keywords = [kw.strip() for kw in user_input.split(",")]

escaped_keywords = [re.escape(k) for k in keywords]
pattern = r'\b(' + '|'.join(escaped_keywords) + r')\b'
resume_skills = re.findall(pattern, resume_text, re.IGNORECASE)
resume_skills = list(set([s.lower() for s in resume_skills]))
# ====== STEP 2: Load semantic model ======
model = SentenceTransformer("sentence-transformers/msmarco-distilbert-base-dot-prod-v3")
resume_emb = model.encode(resume_text, convert_to_tensor=True)

def semantic_similarity(text1_emb, text2):
    text2_emb = model.encode(text2, convert_to_tensor=True)
    return util.pytorch_cos_sim(text1_emb, text2_emb).item()

def extract_skills(text):
    found = [kw for kw in keywords if re.search(rf'\b{kw}\b', text, re.IGNORECASE)]
    return list(set([s.lower() for s in found]))

def fuzzy_match_skills(resume_skills, jd_skills):
    matched = []
    for r in resume_skills:
        for j in jd_skills:
            if fuzz.ratio(r, j) > 91:
                matched.append(j)
    return list(set(matched))

# ====== STEP 3: Selenium config ======
service = Service(r"chromedriver-win64/chromedriver.exe")
driver = webdriver.Chrome(service=service)
wait = WebDriverWait(driver, 30)

try:
    # ====== Login to Dice ======
    driver.get("https://www.dice.com/dashboard/login")
    email_input = wait.until(EC.presence_of_element_located((By.XPATH, '//*[@id="react-aria-:Rd7rkqfncq:"]')))
    email_input.clear()
    wait = WebDriverWait(driver, 10)
    email = input("Enter your Dice email: ")
    email_input.send_keys(email)
    login_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']")))
    login_button.click()

    password_input = wait.until(EC.presence_of_element_located((By.XPATH, '//input[@placeholder="Enter Password"]')))
    password_input.clear()
    wait = WebDriverWait(driver, 10)
    password = input("Enter your Dice password: ")
    password_input.send_keys(password)
    login_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']")))
    login_button.click()

    time.sleep(10)

    # ====== Job search ======
    all_job_links = set()
    # Ask user to input job titles as comma-separated values
    job_titles_input = input("Enter job titles (comma separated): ")
    wait = WebDriverWait(driver, 30)
    # Split the input string by comma and strip extra spaces
    job_titles = [title.strip() for title in job_titles_input.split(",")]

    for title in job_titles:
        search_input = wait.until(EC.element_to_be_clickable((By.NAME, "q")))
        search_input.click()
        driver.execute_script("arguments[0].value = '';", search_input)
        search_input.send_keys(title)
        location_input = wait.until(EC.element_to_be_clickable((By.NAME, "location")))
        location_input.clear()
        location_input.send_keys("Remote")
        search_button = wait.until(EC.element_to_be_clickable((By.CSS_SELECTOR, "button[type='submit']")))
        search_button.click()
        time.sleep(5)
        try:
            filter_button = WebDriverWait(driver, 15).until(
                EC.element_to_be_clickable((By.XPATH, "/html/body/div[3]/div/div[2]/div[1]/div[2]/div[1]/button[1]"))
            )
            filter_button.click()
        except TimeoutException:
            print("Filter button not found.")

        try:
            radio_label = driver.find_element(By.XPATH,
                                              '/html/body/div[3]/div/div[2]/div[2]/div[2]/div/section/div/div[2]/div/form/div/div/label[2]')
            radio_label.click()
        except:
            pass

        try:
            button = WebDriverWait(driver, 20).until(
                EC.element_to_be_clickable(
                    (By.XPATH, '/html/body/div[3]/div/div[2]/div[2]/div[2]/div/div[3]/button[2]'))
            )
            button.click()
        except:
            pass

        time.sleep(5)

        while True:
            elements = driver.find_elements(By.XPATH, '//*[@data-testid="job-search-job-card-link"]')
            for elem in elements:
                href = elem.get_attribute("href")
                if href:
                    all_job_links.add(href)
            try:
                next_btn = driver.find_element(By.XPATH, "/html/body/div[3]/div/div[3]/nav/span[3]/svg")
                driver.execute_script("arguments[0].click();", next_btn)
                time.sleep(2)
            except:
                break

    print(f"Total job links found: {len(all_job_links)}")

    # ====== STEP 4: Match jobs with hybrid score ======
    matched_jobs = []
    for url in all_job_links:
        try:
            driver.get(url)
            time.sleep(5)
            try:
                jd_element = driver.find_element(By.CSS_SELECTOR, '[data-cy="jobDescription"]')
                jd_text = jd_element.text
            except:
                jd_text = driver.find_element(By.TAG_NAME, "body").text

            jd_skills = extract_skills(jd_text)
            skill_matches = fuzzy_match_skills(resume_skills, jd_skills)

            # Compute hybrid score: 70% skills + 30% semantic similarity
            skill_score = (len(skill_matches) / len(jd_skills) * 100) if jd_skills else 0
            sem_score = semantic_similarity(resume_emb, jd_text) * 100
            hybrid_score = round(0.6 * skill_score + 0.4 * sem_score, 2)

            if hybrid_score > 91:  # Threshold for match
                try:
                    company_name = driver.find_element(By.XPATH, '//*[@id="jobdetails"]/div/ul/li[1]/ul/li/a').text
                except:

                    company_name = "Unknown Company"
                matched_jobs.append((company_name, url, hybrid_score, skill_matches))
                print(f"✅ Matched: {company_name} | url: {url} | Hybrid: {hybrid_score}% ")

        except Exception as e:
            print(f"Error processing {url}: {e}")

    # ====== STEP 5: Save results ======
    if matched_jobs:
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.append(["Company Name", "Job URL", "Hybrid %"])
        for job in matched_jobs:
            sheet.append([job[0], job[1], job[2]])
        workbook.save("matched_jobs_hybrid.xlsx")
        print("Saved matched jobs to matched_jobs.xlsx")
    else:
        print("❌ No jobs matched your threshold.")

finally:
    driver.quit()
